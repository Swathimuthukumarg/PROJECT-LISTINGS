const express = require("express");
const router = express.Router();
const db = require("../db");
const md5 = require("md5");

// Combined Login/Register Endpoint
router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ message: "Username and password are required" });
  }

  try {
    const [users] = await db.execute("SELECT * FROM users WHERE username = ?", [username]);
    
    // Registration: If user not found, register them
    if (users.length === 0) {
      // Generate a random 10-character salt
      const salt = Math.random().toString(36).substring(2, 12);
      // Hash the password using MD5 on the plain password then combine with salt and hash again
      const hashedPassword = md5(md5(password) + salt);
      
      // Insert new user into database
      const [result] = await db.execute(
        "INSERT INTO users (username, password, salt) VALUES (?, ?, ?)",
        [username, hashedPassword, salt]
      );
      
      // Create session after registration
      req.session.user = { id: result.insertId, username };
      return res.json({ message: "Registration and login successful" });
    } else {
      // Login path: verify password
      const user = users[0];
      const hashedPassword = md5(md5(password) + user.salt);
      
      if (hashedPassword === user.password) {
        req.session.user = { id: user.user_id, username: user.username };
        return res.json({ message: "Login successful" });
      } else {
        return res.status(401).json({ message: "Invalid password" });
      }
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;

const express = require("express");
const router = express.Router();
const db = require("../db");

// GET /api/projects
router.get("/", async (req, res) => {
  const sort = req.query.sort || "recent";
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 2;
  const offset = (page - 1) * limit;

  let orderBy = "p.created_at DESC";
  if (sort === "category") orderBy = "c.category_name ASC";
  else if (sort === "username") orderBy = "u.username ASC";
  else if (sort === "title") orderBy = "p.title ASC";

  try {
    // ⚠️ Use db.query instead of db.execute for dynamic ORDER BY
    const [data] = await db.query(
      `SELECT p.title, u.username, c.category_name
       FROM projects p
       JOIN users u ON p.user_id = u.user_id
       LEFT JOIN categories c ON p.cid = c.cid
       ORDER BY ${orderBy}
       LIMIT ? OFFSET ?`, 
      [limit, offset]
    );

    const [[{ total }]] = await db.query("SELECT COUNT(*) AS total FROM projects");
    const totalPages = Math.ceil(total / limit);

    res.json({ data, totalPages });
  } catch (err) {
    console.error("Error fetching projects:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// POST /api/projects
router.post("/", async (req, res) => {
  const { title, user_id, cid } = req.body;

  if (!title || !user_id || !cid) {
    return res.status(400).json({ message: "All fields are required" });
  }

  try {
    await db.execute(
      "INSERT INTO projects (title, user_id, cid) VALUES (?, ?, ?)",
      [title, user_id, cid]
    );
    res.json({ message: "Project inserted successfully" });
  } catch (err) {
    console.error("Error inserting project:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

module.exports = router;
